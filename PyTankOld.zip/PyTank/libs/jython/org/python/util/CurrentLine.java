public class CurrentLine {
		
		private int line;
			
		 public	CurrentLine()
			 	{
						 line = 0;
						 	}

		 public int getLine() {
			 	return line;
		 }

		 public void setLine(int line) {
			 	this.line = line;
		 }
}

