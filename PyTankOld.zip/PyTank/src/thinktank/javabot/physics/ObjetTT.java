package thinktank.javabot.physics;

public interface ObjetTT {
	public Physique.type getType();
}