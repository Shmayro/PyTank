package thinktank.javabot.sensors;

public interface Sensors {

}
