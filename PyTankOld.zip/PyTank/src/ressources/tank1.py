tank.moveForward()
tank.moveBackward()
tank.shoot()
tank.distanceOfForwardObstacle()

	
