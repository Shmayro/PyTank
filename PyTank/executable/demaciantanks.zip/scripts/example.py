while True:
	tank.moveForward();
	tank.turnClockwise();
	tank.moveForward();
	tank.shoot();