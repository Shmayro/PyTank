-- README du projet court DemacianTanks du groupe SampleName

-- Pr�conditions
Ce readme est accompagn� des dossiers script/ et ressources/, ainsi que du fichier demaciantanks.jar.

-- Execution
Une fois d�compress�, lancez un invite de commande et �xecutez :
- java -jar <path>/demaciantanks.jar
o� <path> est le chemin du projet d�compress�.

-- Modifications des scripts
Le logiciel demaciantanks poss�de une interface d'�dition de texte int�gr�e. Vous pouvez atteindre les scripts �dit�s dans le dossier scripts/. En atteignant ce dossier vous pouvez renommer ou supprimer un script. Si vous faites ainsi, red�marrez le projet.